//
//  UserDerfaultHelper.swift
//  SkyDo
//
//  Created by Akash Trivedi on 07/05/18.
//  Copyright © 2018 Akash Trivedi. All rights reserved.
//

import Foundation

class UserDefaultHelper {
    fileprivate static let userDefault = UserDefaults.standard
    static func saveUsername(username: String) {
        userDefault.set(username, forKey: USERNAME)
        userDefault.synchronize()
    }
    
    static func getUsername() -> String? {
        return UserDefaults.standard.string(forKey: USERNAME)
    }
    
    static func savePassword(password: String) {
        userDefault.set(password, forKey: PASSWORD)
        userDefault.synchronize()
    }
    
    static func getPassword() -> String? {
        return userDefault.string(forKey: PASSWORD)
    }
    
    static func saveUser(user: User) {
        let dictionary = user.getDictionary()
        userDefault.set(dictionary, forKey: USER)
        userDefault.synchronize()
    }
    
    static func getUser() -> User? {
        let userDictionary: [String: Any] = userDefault.value(forKey: USER) as? [String: Any] ?? [:]
        return User.getInstance(dictionary: userDictionary)
    }
}

