//
//  String.swift
//  DataLogApp
//
//  Created by Logileap on 7/12/19.
//  Copyright © 2019 Logileap. All rights reserved.
//

import Foundation
extension String {
    var trimText: String! {
        return self.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
