//
//  SignUpViewController.swift
//  DataLogApp
//
//  Created by Logileap on 7/12/19.
//  Copyright © 2019 Logileap. All rights reserved.
//

import UIKit

class SignUpViewController: BaseViewController {

    @IBOutlet weak var firstnameTextField: UITextField!
    @IBOutlet weak var lastnameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    //MARK:- Actions
    @IBAction func signUpButtonAction(_ sender: Any) {
     
        let firstname = self.firstnameTextField.text?.trimText ?? ""
        let lastname = self.lastnameTextField.text?.trimText ?? ""
        let email = self.emailTextField.text?.trimText ?? ""
        let password = self.passwordTextField.text?.trimText ?? ""
        let confirmPassword = self.confirmPasswordTextField.text?.trimText ?? ""
        
        if firstname.isEmpty {
            Utility.alert(message: "Please enter firstname.")
        }
        else if lastname.isEmpty {
            Utility.alert(message: "Please enter firstname.")
        }
        else if email.isEmpty {
            Utility.alert(message: "Please enter firstname.")
        }
        else if password.isEmpty {
            Utility.alert(message: "Please enter password.")
        }
        else if confirmPassword.isEmpty {
            Utility.alert(message: "Please enter confirm password.")
        }
        else if password.count < 5 || confirmPassword.count < 5 {
            Utility.alert(message: passwordLengthErrorMessage)
        }
        else if password.count != confirmPassword.count {
            Utility.alert(message: "Password and Confirm Password does not match.")
        }
        else {
            let sigupRequest = Register(firstname: firstname, lastname: lastname, email: email, password: password)
            sigupRequest.register { (response, error) in
                if error == nil {
                    if let userData = response?.user {
                        UserDefaultHelper.saveUser(user: userData)
                        UserDefaultHelper.saveUsername(username: email)
                        UserDefaultHelper.savePassword(password: password)
                        AppData.sharedInstance.user = UserDefaultHelper.getUser()
                        let vc = AppData.sharedInstance.storyBoard.instantiateViewController(withIdentifier: "home")
                        AppDelegate.getAppDelegate().window?.rootViewController = vc
                    } else {
                        Utility.alert(message: response?.message ?? apiErrorMessage)
                    }
                } else {
                    Utility.alert(message: error?.localizedDescription ?? apiErrorMessage)
                }
            }
        }
        
    }
    @IBAction func loginButtonAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
