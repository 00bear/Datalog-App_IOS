//
//  HomeViewViewController.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/2/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import UIKit
import DatePickerDialog

class HomeViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var selectDateButton: UIButton!
    var refreshControl = UIRefreshControl()
    
    var datalogList: [Datalog] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getLastDataLog()
        
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(getLastDataLog), for: UIControl.Event.valueChanged)
        tableView.addSubview(refreshControl)
        // Do any additional setup after loading the view.
    }
    
    // MARK: - Button Tapped
    @IBAction func selectDateButtonTapped(_ sender: Any) {
        DatePickerDialog().show("DatePicker", doneButtonTitle: "Select", cancelButtonTitle: "Cancel", maximumDate: Date(), datePickerMode: .date) {
            (date) -> Void in
            if let dt = date {
                let viewController = self.storyboard?.instantiateViewController(withIdentifier: "DataViewController") as! DataViewController
                viewController.selectedDate = dt
                self.navigationController?.pushViewController(viewController, animated: true)
            }
        }
    }
    
    @IBAction func settingButtonTapped(_ sender: Any) {
        let viewController = self.storyboard?.instantiateViewController(withIdentifier: "ChangePasswordViewController") as! ChangePasswordViewController
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    @objc func getLastDataLog() {
        LastDatalogRequest.getLastDatalog { (datalogResponse, error) in
            if error == nil {
                self.refreshControl.endRefreshing()
                self.datalogList = datalogResponse?.datalogs ?? []
                self.tableView.reloadData()
            } else {
                Utility.alert(message: error?.localizedDescription ?? "")
            }
        }
    }
    
}

extension HomeViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.datalogList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! DetailTableViewCell
        cell.datalog = self.datalogList[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let viewController = self.storyboard!.instantiateViewController(withIdentifier: "MapViewController") as! MapViewController
        viewController.datalog = self.datalogList[indexPath.row]
        self.navigationController?.pushViewController(viewController, animated: true) 
    }
}
