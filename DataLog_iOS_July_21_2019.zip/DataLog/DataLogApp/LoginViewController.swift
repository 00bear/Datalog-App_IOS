//
//  LoginViewController.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/2/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import UIKit

class LoginViewController: BaseViewController {
    
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var loginButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    // MARK: - Login Button Tapped
    @IBAction func loginButtonTapped(_ sender: Any) {
        
        let username = userNameTextField.text!.trimText
        let password = passwordTextField.text!.trimText
        
        if username!.isEmpty {
            Utility.alert(message: "Enter Username")
        } else if password!.isEmpty {
            Utility.alert(message: "Enter Password")
        } else if password!.count < 5 {
            Utility.alert(message: passwordLengthErrorMessage)
        } else {
            LoginRequest.authenticate(username: username!, password: password!) { (response, error) in
                if error == nil {
                    if let userData = response?.user {
                        UserDefaultHelper.saveUsername(username: username!)
                        UserDefaultHelper.savePassword(password: password!)
                        UserDefaultHelper.saveUser(user: userData)
                        AppData.sharedInstance.user = UserDefaultHelper.getUser()
                        let vc = AppData.sharedInstance.storyBoard.instantiateViewController(withIdentifier: "home")
                        AppDelegate.getAppDelegate().window?.rootViewController = vc
                    } else {
                        Utility.alert(message: response?.message ?? apiErrorMessage)
                    }
                } else {
                    Utility.alert(message: error?.localizedDescription ?? apiErrorMessage)
                }
            }
        }
    }
    @IBAction func signUpButtonAction(_ sender: Any) {
        let controller = AppData.sharedInstance.storyBoard.instantiateViewController(withIdentifier: "SignUpViewController")
        controller.modalTransitionStyle = .crossDissolve
        controller.modalPresentationStyle = .overFullScreen
        self.present(controller, animated: true, completion: nil)
    }
    
}
