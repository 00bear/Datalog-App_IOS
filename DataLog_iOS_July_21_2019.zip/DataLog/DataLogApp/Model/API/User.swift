//
//  User.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/3/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import Foundation

class User {
    var id: Int?
    var username: String?
    var createdAt: Double?
    var updatedAt: Double?

    init(dictionary: [String: Any]) {
        self.id = dictionary["id"] as? Int
        self.username = dictionary["username"] as? String
        self.createdAt = dictionary["createdAt"] as? Double
        self.updatedAt = dictionary["updatedAt"] as? Double
    }

    class func getInstance(dictionary: [String: Any]) -> User? {
        let response = User(dictionary: dictionary)
        if response.id != nil {
            return response
        }
        return nil
    }
    
    func getDictionary() -> [String: Any] {
        var dictionary: [String: Any] = [:]
        dictionary["id"] = self.id
        dictionary["username"] = self.username
        dictionary["createdAt"] = self.createdAt
        dictionary["updatedAt"] = self.updatedAt
        return dictionary
    }


}
