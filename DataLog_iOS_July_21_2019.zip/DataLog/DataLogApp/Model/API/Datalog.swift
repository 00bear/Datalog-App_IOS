//
//  Datalog.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/3/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import Foundation

class Datalog {
    var id: Int?
    var temprature: String?
    var datetime: String?
    var latitude: Double?
    var longitude: Double?
    var motion: Bool?
    var createdAt: Double?
    var updatedAt: Double?
    
    
    init(dictionary: [String: Any]) {
        self.id = dictionary["id"] as? Int
        self.temprature = dictionary["temprature"] as? String
        self.datetime = dictionary["datetime"] as? String
        self.latitude = dictionary["latitude"] as? Double
        self.longitude = dictionary["longitude"] as? Double
        self.motion = dictionary["motion"] as? Int != nil && dictionary["motion"] as? Int != 0
        self.createdAt = dictionary["createdAt"] as? Double
        self.updatedAt = dictionary["updatedAt"] as? Double
    }
    
    class func getInstance(dictionary: [String: Any]) -> Datalog? {
        let response = Datalog(dictionary: dictionary)
        if response.id != nil {
            return response
        }
        return nil
    }
    
    class func getList(array: [[String: Any]]) -> [Datalog]? {
        var list: [Datalog] = []
        for a in array {
            if let object = Datalog.getInstance(dictionary: a) {
                list.append(object)
            }
        }
        return list.count > 0 ? list : nil
    }
}
