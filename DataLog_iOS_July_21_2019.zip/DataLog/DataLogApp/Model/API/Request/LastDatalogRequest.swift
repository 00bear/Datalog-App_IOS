//
//  DatalogRequest.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/2/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import Foundation

class LastDatalogRequest {
   
    static func getLastDatalog(callback: @escaping ((_ list: LastDatalogResponse?, _ error: Error?) -> Void)) {
        Utility.showProgress("")
        let parameter = ["username": UserDefaultHelper.getUsername()!,
                         "password": UserDefaultHelper.getPassword()!]
        Utility.apiCall(GET_LAST_DATA_API, data: parameter, apiType: ApiType.lastGetDataLog, method: .GET) { (success, response, error, api) in
            Utility.dismissProgress()
            if success {
                if let responseDictionary = response as? [String: Any] {
                    let instance = LastDatalogResponse.getInstance(dictionary: responseDictionary)
                    callback(instance, nil)
                }
            } else {
                callback(nil, error)
            }
        }
    }
}
