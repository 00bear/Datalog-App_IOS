//
//  ChangePasswordRequest.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/2/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import Foundation

class ChangePasswordRequest {
    var username: String
    var oldPassword: String
    var newPassword: String
    
    init(username: String, oldPassword: String, newPassword: String) {
        self.username = username
        self.oldPassword = oldPassword
        self.newPassword = newPassword
    }
    
    func getDictionary() -> [String: Any] {
        var dictionary: [String: Any] = [:]
        dictionary["username"] = self.username
        dictionary["oldPassword"] = self.oldPassword
        dictionary["newPassword"] = self.newPassword
        return dictionary
    }
    
    static func changePassword(param: ChangePasswordRequest, callback: @escaping ((_ response: ChangePasswordResponse?, _ error: Error?) -> Void)) {
        Utility.showProgress("")
        let request = param
        Utility.apiCall(CHANGE_PASSWORD_API, data: request.getDictionary(), apiType: ApiType.changePassword, method: .POST) { (success, response, error, api) in
            Utility.dismissProgress()
            if success {
                if let responseDictionary = response as? [String: Any] {
                    let instance = ChangePasswordResponse.getInstance(dictionary: responseDictionary)
                        callback(instance, nil)
                }
            } else {
                callback(nil, error)
            }
        }
    }
}
