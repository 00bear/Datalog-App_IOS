//
//  LoginRequest.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/2/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import Foundation

class LoginRequest {
    var username: String
    var password: String
    
    init(username: String, password: String) {
        self.username = username
        self.password = password
    }
    
    func getDictionary() -> [String: Any] {
        var dictionary: [String: Any] = [:]
        dictionary["username"] = self.username
        dictionary["password"] = self.password
        return dictionary
    }
    
    static func authenticate(username: String, password: String, callback: @escaping ((_ response: LoginResponse?, _ error: Error?) -> Void)) {
        Utility.showProgress("")
        let request = LoginRequest(username: username, password: password)
        Utility.apiCall(LOGIN_API, data: request.getDictionary(), apiType: ApiType.login, method: .GET) { (success, response, error, api) in
            Utility.dismissProgress()
            if success {
                if let responseDictionary = response as? [String: Any] {
                    let instance = LoginResponse.getInstance(dictionary: responseDictionary)
                    callback(instance, nil)
                }
            } else {
                callback(nil, error)
            }
        }
    }
}
class Register {
    var firstname: String
    var lastname: String
    var email: String
    var password: String
    
    init(firstname: String, lastname: String, email: String, password: String) {
        self.firstname = firstname
        self.lastname = lastname
        self.email = email
        self.password = password
    }
    
    func getDictionary() -> [String: Any] {
        var dictionary: [String: Any] = [:]
        dictionary["firstname"] = self.firstname
        dictionary["lastname"] = self.lastname
        dictionary["username"] = self.email
        dictionary["password"] = self.password
        return dictionary
    }
    
    func register(callback: @escaping ((_ response: LoginResponse?, _ error: Error?) -> Void)) {
        Utility.showProgress("")
        Utility.apiCall(SIGNUP_API, data: self.getDictionary(), apiType: ApiType.signUp, method: .GET) { (success, response, error, api) in
            Utility.dismissProgress()
            if success {
                if let responseDictionary = response as? [String: Any] {
                    let instance = LoginResponse.getInstance(dictionary: responseDictionary)
                    callback(instance, nil)
                }
            } else {
                callback(nil, error)
            }
        }
    }
}
