//
//  DatalogRequest.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/2/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import Foundation

class DatalogRequest {
    var date: Date
    
    init(date: Date) {
        self.date = date
    }
    
    func getDictionary() -> [String: Any] {
        var dictionary: [String: Any] = [:]
        dictionary["time"] = self.date.toString(dateFormat: SERVER_DATE_FORMAT)
        dictionary["username"] = UserDefaultHelper.getUsername()!
        dictionary["password"] = UserDefaultHelper.getPassword()!
        return dictionary
    }
    
    static func getDatalog(date: Date = Date(), callback: @escaping ((_ list: DatalogResponse?, _ error: Error?) -> Void)) {
        Utility.showProgress("")
        let datalogRequest = DatalogRequest(date: date)
        Utility.apiCall(GET_DATA_API, data: datalogRequest.getDictionary(), apiType: ApiType.getDataLog, method: .GET) { (success, response, error, api) in
            Utility.dismissProgress()
            if success {
                if let responseDictionary = response as? [String: Any] {
                        let instance = DatalogResponse.getInstance(dictionary: responseDictionary)
                        callback(instance, nil)
                }
            } else {
                callback(nil, error)
            }
        }
    }
}
