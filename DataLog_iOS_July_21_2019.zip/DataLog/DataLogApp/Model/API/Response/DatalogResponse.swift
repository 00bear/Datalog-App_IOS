//
//  DatalogResponse.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/2/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import Foundation

class DatalogResponse {
    var status: String?
    var datalogs: [Datalog]?
    var message: String?
    
    init(dictionary: [String: Any]) {
        self.status = dictionary["status"] as? String
        if let datalogArray = dictionary["datalogs"] as? [[String: Any]] {
            self.datalogs = Datalog.getList(array: datalogArray)
        }
        self.message = dictionary["message"] as? String
    }
    
    class func getInstance(dictionary: [String: Any]) -> DatalogResponse? {
        let response = DatalogResponse(dictionary: dictionary)
        if response.status != nil {
            return response
        }
        return nil
    }
}
