//
//  ChangePasswordResponse.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/2/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import Foundation

class ChangePasswordResponse {
    var message: String?
  
    init(dictionary: [String: Any]) {
        self.message = dictionary["message"] as? String
    }
    
    class func getInstance(dictionary: [String: Any]) -> ChangePasswordResponse? {
        let response = ChangePasswordResponse(dictionary: dictionary)
        return response
    }
}
