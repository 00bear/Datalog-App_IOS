//
//  DatalogResponse.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/2/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import Foundation

class LastDatalogResponse {
    var status: String?
    var datalogs: [Datalog]?

    init(dictionary: [String: Any]) {
        self.status = dictionary["status"] as? String
        if let datalogArray = dictionary["datalogs"] as? [[String: Any]] {
            self.datalogs = Datalog.getList(array: datalogArray)
        }
    }
    
    class func getInstance(dictionary: [String: Any]) -> LastDatalogResponse? {
        let response = LastDatalogResponse(dictionary: dictionary)
        if response.status != nil {
            return response
        }
        return nil
    }
}
