//
//  LoginResponse.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/2/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import Foundation

class LoginResponse {
    var status: String?
    var user: User?
    var message: String?
    
    init(dictionary: [String: Any]) {
        self.status = dictionary["status"] as? String
        if let userDictionary = dictionary["user"] as? [String: Any] {
            self.user = User.getInstance(dictionary: userDictionary)
        }
        self.message = dictionary["message"] as? String
    }
    
    class func getInstance(dictionary: [String: Any]) -> LoginResponse? {
        let response = LoginResponse(dictionary: dictionary)
        if response.status != nil {
            return response
        }
        return nil
    }
}

