//
//  ChangePasswordViewController.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/2/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import UIKit

class ChangePasswordViewController: UIViewController {

    @IBOutlet weak var oldPasswordTextField: UITextField!
    @IBOutlet weak var newPasswordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    
    @IBOutlet weak var changePasswordButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.addTapGesture()
        // Do any additional setup after loading the view.
    }
    func addTapGesture() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @IBAction func logoutTapped(_ sender: Any) {
        let vc = AppData.sharedInstance.storyBoard.instantiateViewController(withIdentifier: "login")
        AppData.sharedInstance.user = nil
        UserDefaults.standard.removeObject(forKey: USER)
        AppDelegate.getAppDelegate().window!.rootViewController = vc
    }
    
    // MARK: - Button Tapped
    @IBAction func changePasswordButtonTapped(_ sender: Any) {
        if oldPasswordTextField.text!.isEmpty {
            Utility.alert(message: "Enter Old Password")
        } else if newPasswordTextField.text!.isEmpty {
            Utility.alert(message: "Enter New Password")
        } else if newPasswordTextField.text!.count < 5 {
            Utility.alert(message: passwordLengthErrorMessage)
        } else if confirmPasswordTextField.text!.isEmpty {
            Utility.alert(message: "Enter Confirm Password")
        } else if newPasswordTextField.text != confirmPasswordTextField.text {
            Utility.alert(message: "New Password and Confirm password are not same")
        } else {
            let changePass = ChangePasswordRequest(username: AppData.sharedInstance.user.username!, oldPassword: oldPasswordTextField.text!, newPassword: newPasswordTextField.text!)
            ChangePasswordRequest.changePassword(param: changePass) { (response, error) in
                if error == nil {
                    if response?.message == "Password updated successfully." {
                        UserDefaultHelper.savePassword(password: self.newPasswordTextField.text!)
                        Utility.alert(message: response?.message ?? "")
                        self.navigationController?.popViewController(animated: true)
                    } else {
                         Utility.alert(message: response?.message ?? "")
                    }
                }
                 else {
                    Utility.alert(message: error?.localizedDescription ?? "")
                }
            }
        }
    }

}
