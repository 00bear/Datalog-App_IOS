//
//  DataViewController.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/2/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import UIKit

class DataViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var refreshControl = UIRefreshControl()
    var datalogList: [Datalog] = []
    var selectedDate: Date!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.getDataLog()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(getDataLog), for: UIControl.Event.valueChanged)
        tableView.addSubview(refreshControl)
    }
    
    @objc func getDataLog() {
        DatalogRequest.getDatalog(date: self.selectedDate, callback: { (datalogResponse: DatalogResponse?, error: Error?) in
            self.refreshControl.endRefreshing()
            if error == nil {
                self.datalogList = datalogResponse?.datalogs ?? []
                self.tableView.reloadData()
            } else {
                Utility.alert(message: error?.localizedDescription ?? "")
            }
        })
    }
}

extension DataViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.datalogList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! DetailTableViewCell
        cell.datalog = self.datalogList[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let viewController = self.storyboard!.instantiateViewController(withIdentifier: "MapViewController") as! MapViewController
        viewController.datalog = self.datalogList[indexPath.row]
        self.navigationController?.pushViewController(viewController, animated: true) 
    }
}
