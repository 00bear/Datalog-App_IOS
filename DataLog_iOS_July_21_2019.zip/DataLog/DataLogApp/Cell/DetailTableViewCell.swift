//
//  DetailTableViewCell.swift
//  DataLogApp
//
//  Created by Bhautik Gadhiya on 12/22/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import UIKit

class DetailTableViewCell: UITableViewCell {

    @IBOutlet weak var tempratureLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var latLongLabel: UILabel!
    @IBOutlet weak var motionLabel: UILabel!

    var datalog: Datalog! {
        didSet {
            self.tempratureLabel.text = "Temperature: " + (self.datalog.temprature ?? "")
            self.dateLabel.text = "Date: " + (self.datalog.datetime ?? "")
            self.latLongLabel.text = "Locaton: " + "\((self.datalog.latitude ?? 0)), \((self.datalog.longitude ?? 0))"
            self.motionLabel.text = "Motion Detected: " + (self.datalog.motion! ? "Yes" : "No")
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
