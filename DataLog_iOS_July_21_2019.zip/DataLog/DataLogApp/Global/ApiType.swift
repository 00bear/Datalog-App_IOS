//
//  ApiType.swift
//  Brief
//
//  Created by Akash Trivedi on 10/24/17.
//  Copyright © 2017 Equinix. All rights reserved.
//

import Foundation

@objc enum ApiType: Int {
    case getDataLog
    case lastGetDataLog
    case login
    case signUp
    case changePassword
}
