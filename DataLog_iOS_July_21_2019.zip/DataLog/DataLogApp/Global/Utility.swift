////
////  Utility.swift
////  Brief
////
////  Created by Akash Trivedi on 10/24/17.
////  Copyright © 2017 Equinix. All rights reserved.
////
//
import Foundation
import UIKit
import SVProgressHUD
import Reachability


class Utility {
    
    class func showProgress(_ message: String) {
        SVProgressHUD.setDefaultMaskType(SVProgressHUDMaskType.black)
        if(message == "") {
            SVProgressHUD.show()
        }
        else {
            SVProgressHUD.show(withStatus: message)
        }
    }
    
    class func dismissProgress() {
        SVProgressHUD.dismiss()
    }

    class func alert(message: String, title: String? = "Alert!") {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alert.addAction(action)
            alert.show()
        }
    }
  
    // MARK : API Call
    class func apiCall(_ urlString: String, data: [String: Any]?, apiType: ApiType, method: HTTPMethod, callback: ((_ success: Bool, _ data: Any?, _ error: Error?, _ apiType: ApiType) -> Void)?) {
        
        if Utility.checkInternet() {
            var url: URL! = URL(string: urlString)!
            var query = ""
            if(data != nil) {
                let parameters = data!.keys
                var i = 0
                for parameter in parameters {
                    query += "\(parameter)=\(data![parameter]!)&"
                    i += 1
                }
                if(i > 0) {
                    _ = query.removeLast()
                }
            }
            if(method == .GET) {
                url = URL(string: urlString + query.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!)!
            }
            var request = URLRequest(url: url!)
            request.httpMethod = method.rawValue
            if(method == .PUT || method == .POST) {
                request.httpBody =  query.data(using: .utf8) ?? Data()
            }
           
            let config = URLSessionConfiguration.default
            config.timeoutIntervalForRequest = 60
            config.timeoutIntervalForResource = 60
            
            let session = URLSession(configuration: config)
            print("Start: \(Date()), \(url.absoluteString)")
            let task = session.dataTask(with: request, completionHandler: { (data: Data?, response: URLResponse?, error: Error?) in
                print("End: \(Date()), \(url.absoluteString)")
                DispatchQueue.main.async(execute: {
                    if(error == nil){
                        if let d = try? JSONSerialization.jsonObject(with: data!, options: []) {
                            callback?(true, d, nil, apiType)
                        }
                        else {
                            let message = data != nil ? String(data: data!, encoding: .utf8) ?? "" : ""
                            let error = NSError(domain: message, code: 0, userInfo: nil)
                            callback?(false, nil, error, apiType)
                        }
                    }
                    else {
                        callback?(false, nil, error, apiType)
                    }
                })
            })
            task.resume()
        } else {
            Utility.alert(message: "Check your network connection.")
        }
    }
    
    
    class func checkInternet() -> Bool {
        let networkReachability: Reachability = Reachability.forInternetConnection();
        let networkStatus : NetworkStatus = networkReachability.currentReachabilityStatus();
        if (networkStatus.rawValue == 0) {
            return false
        } else {
            return true
        }
    }
}

private var kAlertControllerWindow = "kAlertControllerWindow"
extension UIAlertController {
    
    var alertWindow: UIWindow? {
        get {
            return objc_getAssociatedObject(self, &kAlertControllerWindow) as? UIWindow
        }
        set {
            objc_setAssociatedObject(self, &kAlertControllerWindow, newValue, .OBJC_ASSOCIATION_RETAIN)
        }
    }
    
     func show() {
        show(animated: true)
    }
    
    func show(animated: Bool) {
        alertWindow = UIWindow(frame: UIScreen.main.bounds)
        alertWindow?.rootViewController = UIViewController()
        alertWindow?.windowLevel = UIWindow.Level.alert + 1
        alertWindow?.makeKeyAndVisible()
        alertWindow?.rootViewController?.present(self, animated: animated, completion: nil)
    }
    
    open override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        alertWindow?.isHidden = true
        alertWindow = nil
    }
}
