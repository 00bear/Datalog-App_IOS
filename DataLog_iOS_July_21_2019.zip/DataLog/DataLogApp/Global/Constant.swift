//
//  Constant.swift
//  DataLogApp
//
//  Created by Logileap on 30/11/18.
//  Copyright © 2018 Logileap. All rights reserved.
//

import Foundation

let AppName = "DataLog"
let USER = "USER"
let USERNAME = "USERNAME"
let PASSWORD = "PASSWORD"
let SERVER_DATE_FORMAT      =   "yyyy-MM-dd"
let BASE_URL                =   "https://cleartemp.site/"
//let BASE_URL                =   "http://localhost/"
let GET_DATA_API            =   BASE_URL + "datalog/datalog.php?"
let LOGIN_API               =   BASE_URL + "datalog/login.php?"
let SIGNUP_API               =  BASE_URL + "datalog/signup.php?"
let CHANGE_PASSWORD_API     =   BASE_URL + "datalog/updatePassword.php"
let GET_LAST_DATA_API       =   BASE_URL + "datalog/getLastLog.php?"

//Error Messages

let passwordLengthErrorMessage = "Password must be greater than or equal to 6 characters."
let apiErrorMessage = "Please try again after sometime."
