//
//  AppData.swift
//  Amber
//
//  Created by Bhautik Gadhiya on 12/5/17.
//  Copyright © 2017 Bhautik Gadhiya. All rights reserved.
//


import Foundation
import UIKit
import CoreLocation

class AppData {
    
    var appDelegate: AppDelegate!
    var storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
    var user: User!
    
    static let sharedInstance: AppData = {
        let instance = AppData()

        return instance
    }()
    
    private init() {}

}
